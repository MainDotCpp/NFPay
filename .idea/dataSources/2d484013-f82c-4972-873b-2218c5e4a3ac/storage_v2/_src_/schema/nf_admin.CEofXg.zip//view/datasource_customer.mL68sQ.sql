create definer = yy@`%` view datasource_customer as
select `c`.`id`                              AS `id`,
       `c`.`name`                            AS `客户名`,
       `c`.`wx_id`                           AS `微信号`,
       `c`.`phone`                           AS `手机号`,
       `nf_admin`.`system_dict_data`.`label` AS `拍摄类型`,
       `c`.`channel_name`                    AS `渠道`,
       `sdd2`.`label`                        AS `跟进状态`,
       `c`.`create_time`                     AS `创建时间`,
       `c`.`seller_user_name`                AS `销售`,
       `c`.`creator_name`                    AS `录入人`,
       `c`.`remark`                          AS `备注`,
       `c`.`expected_date_of_birth`          AS `预产期`
from ((`nf_admin`.`customer` `c` left join `nf_admin`.`system_dict_data`
       on (((`c`.`photo_type` = `nf_admin`.`system_dict_data`.`value`) and
            (`nf_admin`.`system_dict_data`.`dict_type` = 'photo_type')))) left join `nf_admin`.`system_dict_data` `sdd2`
      on (((`c`.`follow_up_state_id` = `sdd2`.`value`) and (`sdd2`.`dict_type` = 'follow_up_type'))))
where ((`c`.`tenant_id` = 1686669924547186690) and
       (date_format(`c`.`create_time`, '%Y-%m') = date_format(now(), '%Y-%m')));

-- comment on column datasource_customer.id not supported: 客户id

-- comment on column datasource_customer.客户名 not supported: 客户名

-- comment on column datasource_customer.微信号 not supported: 微信号

-- comment on column datasource_customer.手机号 not supported: 手机号

-- comment on column datasource_customer.拍摄类型 not supported: 字典标签

-- comment on column datasource_customer.渠道 not supported: 渠道名

-- comment on column datasource_customer.跟进状态 not supported: 字典标签

-- comment on column datasource_customer.创建时间 not supported: 创建时间

-- comment on column datasource_customer.销售 not supported: 销售

-- comment on column datasource_customer.录入人 not supported: 录入人姓名

-- comment on column datasource_customer.备注 not supported: 备注

-- comment on column datasource_customer.预产期 not supported: 预产期

